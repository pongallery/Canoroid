# Canoroid สำหรับ EOS 600D

รุ่นทดสอบขั้นแรกสำหรับ Canon EOS 600D เฟิร์มแวร์ **1.0.2** ใช้ JPEG หนึ่งไฟล์จากการ์ด ครอปตรงกลางเป็น 1:1 และใส่กรอบลงใน JPEG ใหม่ขนาด 1080 × 1080 พิกเซล Canoroid ใช้หน้าจอของตัวเองและแสดงภาพที่เปิดอ่านกลับจากไฟล์ที่เขียนแล้ว

## บิลด์และแพ็ก

ใช้ GNU Make, GCC สำหรับเครื่องบิลด์, GCC/binutils/newlib headers สำหรับ `arm-none-eabi`, Python 3, curl และเครื่องมือ tar กับ sha256sum ใช้เชลล์ Linux จากโฟลเดอร์ firmware

```sh
make -C platform/600D.102 clean
make -C platform/600D.102 -j4 CANOROID=y canoroid-packages
```

ไฟล์อยู่ใน `platform/600D.102/build/` ตั้ง `ARM_BINPATH` หากเครื่องมือ ARM อยู่นอก `/usr/bin` บิลด์ Canoroid ปิด TCC และโมดูลเสริม และตัวลิงก์ตรวจขอบเขตหน่วยความจำบูตของ 600D ก่อนแพ็ก หากสลับไปบิลด์ฐาน Magic Lantern ให้รัน `clean` ก่อน

- **FIRST-INSTALL** มี `ML-SETUP.FIR` ที่ Magic Lantern จัดให้สำหรับรุ่นนี้ ใช้การ์ดทดสอบ FAT32 คัดลอกไฟล์ที่แตกแล้วลงรากการ์ด ตรวจเฟิร์มแวร์และแบตเตอรี่ก่อนเข้าเมนู Firmware ของ Canon เพื่อเรียกตัวติดตั้ง
- **UPDATE** ใช้กับกล้องและการ์ดที่เปิดบูต Magic Lantern แล้ว คัดลอกไฟล์ที่แตกแล้วลงรากการ์ดโดยอัปเดต `autoexec.bin` และรวมโฟลเดอร์ `ML` สำรองข้อมูลการ์ดก่อนเปลี่ยนไฟล์ หากใช้การ์ดที่มีการตั้งค่า Magic Lantern จากรุ่นอื่น ให้ใช้การ์ดทดสอบแยกเพื่อให้ทราบว่าการตั้งค่าใดอยู่ในการทดสอบ

ทั้งสองแพ็กเกจเป็นบิลด์ทดสอบ การบูต การติดตั้ง การคืนหน้าจอให้ Canon และการเขียนการ์ดยังต้องตรวจบน EOS 600D จริง

## ถ่ายภาพด้วย 0.1.0-alpha (รุ่นที่ 4)

เลือกโหมด P, Av, Tv หรือ M และคุณภาพ JPEG หรือ RAW+JPEG ใช้การถ่ายทีละภาพบนจอหลังกล้อง

1. เปิดกล้อง เลือก Shoot with frame หรือ Monochrome print ด้วยปุ่มทิศทางและ SET
2. เลือกกรอบแล้วกด SET กล้องจะเข้าสู่ Live View เส้นนอกเป็นพื้นที่ 1:1 และเส้นในเป็นพื้นที่ภาพที่มองเห็นในกรอบ ใช้ Live View แบบขยาย 1×
3. กดชัตเตอร์ตามปกติ Canoroid ติดตามหมายเลขภาพ รอ JPEG บนการ์ด แล้วเริ่มเขียนและตรวจอ่านภาพใส่กรอบ เก็บไฟล์ใน ML/CANOROID โดยใช้ชื่อ P####.JPG
4. เมื่อเห็นผล กดซ้าย/ขวาเพื่อเปรียบเทียบภาพต้นฉบับและภาพใส่กรอบของช็อตเดียวกัน ตัวอย่างบนจอใช้พาเลตต์สีเทา กด SET เพื่อถ่ายต่อ PLAY เพื่อกลับหน้าหลัก หรือ MENU เพื่อใช้ Canon
5. หน้าหลักมี View last print หลังบันทึกสำเร็จ ใช้ดูช็อตล่าสุดในการเปิดกล้องรอบนั้น

ผู้ใช้ยืนยันว่ารุ่นก่อนเข้า Live View และถ่ายได้บน 600D จริง รุ่นที่ 4 แสดงสถานะขณะรอ JPEG และประมวลผลแม้จอ Canon เปลี่ยนจาก Quick Review กลับ Live View กดถังขยะจากหน้าถ่ายภาพหรือเมนู Canon เพื่อกลับ Canoroid ผลหลังถ่ายในรุ่นนี้ยังรอยืนยันบนกล้องจริง

## ทดสอบตัวประมวลผลบนคอมพิวเตอร์

```sh
make -C tools/canoroid
tools/canoroid/build/canoroid-print INPUT.JPG framed.jpg 1
```

เลือกกรอบด้วยเลข 1–3 เอาต์พุตต้องเป็นชื่อไฟล์ใหม่ ตัวทดสอบใช้โค้ดประมวลผลและตัวแปลง JPEG ชุดเดียวกับกล้อง แต่ใช้ระบบไฟล์ของเครื่องบิลด์

ทดสอบด้วย [JPEG ขนาดเต็มจาก EOS 600D](https://commons.wikimedia.org/wiki/File:Canon_EOS_600D_Example.jpg) และ JPEG ที่ฝังอยู่ใน [CR2 ของ EOS 600D จาก raw.pixls.us](https://raw.pixls.us/) ทดสอบครอป ขนาด ขอบสี การเปิดไฟล์ซ้ำ รวมถึงไฟล์ขาด ไฟล์เสีย JPEG แบบ progressive และการป้องกันเขียนทับเอาต์พุตเดิม

## เครดิต

- ฐานบูต พอร์ต 600D ตัวติดตั้ง การเข้าถึงระบบไฟล์ และงานวาดบิตแมปมาจาก [Magic Lantern](https://github.com/reticulatedpines/magiclantern_simplified) ภายใต้ GPL-2.0 ดู `COPYING` และเครดิตในแต่ละไฟล์
- ใช้ [M-Film](https://github.com/HNGSeries/mfilm-canon-film-simulation) เป็นแหล่งอ้างอิงการคืนการควบคุมจอให้ Canon และ [ข้อมูลพื้นที่บูตของ 600D](https://github.com/HNGSeries/mfilm-canon-film-simulation/blob/main/ml-dev/MEMORY.md) หน้าจอและขั้นตอนเลือกกรอบเขียนสำหรับ Canoroid
- This software is based in part on the work of the Independent JPEG Group. บิลด์ใช้ IJG JPEG 9f ที่ตรวจ SHA-256 และปรับตัวเลือกคอมไพล์ให้ใช้ตัวแปลง JPEG แบบ single-scan ขนาดเล็ก แพ็กเกจมีประกาศสิทธิ์ IJG ใน `ML/CANOROID-IJG.txt`
- โค้ดขั้นทดลอง Canoroid ในสาขานี้จัดทำด้วยความช่วยเหลือของ Codex
